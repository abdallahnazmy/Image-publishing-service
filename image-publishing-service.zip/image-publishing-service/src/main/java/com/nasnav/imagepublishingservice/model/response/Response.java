/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.springframework.http.HttpStatus;

/**
 *
 * @author abdallah.nazmy
 */
@JsonInclude(Include.NON_NULL)
public class Response {

    private Object object;
    private String message;

    public Response(Object object) {
        this.object = object;
    }

    public Response(String message) {
        this.message = message;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public String getMessage() {
        return message;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setMessage(String message) {
        this.message = message;
    }

}
