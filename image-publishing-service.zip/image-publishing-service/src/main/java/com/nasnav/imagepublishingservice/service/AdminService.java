/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.service;

import com.nasnav.imagepublishingservice.entity.Admin;
import com.nasnav.imagepublishingservice.repository.AdminRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author abdallah.nazmy
 */
@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public List<Admin> getAdmins() {
        return adminRepository.findAll();
    }

    public Admin getAdminById(Integer AdminId) {
        return adminRepository.getById(AdminId);
    }

    public void generateAdmin() {
        adminRepository.save(new Admin());
    }
}
