/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.service;

import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.repository.ClientRepository;
import com.nasnav.imagepublishingservice.utilities.validators.ClientValidator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 *
 * @author abdallah.nazmy
 */
@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    public void signUp(Client client) {
        clientRepository.save(client);
    }

    public List<Client> getClients() {
        return clientRepository.findAll();
    }

    public Client getClientById(Long clientId) {
        return clientRepository.getById(clientId);
    }
}
