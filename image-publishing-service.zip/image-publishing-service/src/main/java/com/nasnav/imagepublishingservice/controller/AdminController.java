/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.controller;

import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.entity.Admin;
import com.nasnav.imagepublishingservice.entity.Picture;
import com.nasnav.imagepublishingservice.service.AdminService;
import com.nasnav.imagepublishingservice.service.PictureService;
import com.nasnav.imagepublishingservice.utilities.validators.AdminValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author abdallah.nazmy
 */
@RestController
@RequestMapping(value = ApiEndPoints.ADMIN_CONTROLLER.CONTROLLER_NAME)
public class AdminController {

    @Autowired
    private PictureService pictureService;

    @Autowired
    private AdminService adminService;

    @PostMapping(value = ApiEndPoints.ADMIN_CONTROLLER.CREATE_ADMIN)
    public ResponseEntity createAdmin() {
        adminService.generateAdmin();
        return new ResponseEntity("Sucessfully created admin", HttpStatus.OK);
    }

    @GetMapping(value = ApiEndPoints.ADMIN_CONTROLLER.GET_UNPROCESSED_PICTURES)
    public ResponseEntity getUnprocessedPictures() {
        return new ResponseEntity(pictureService.getUnprocessedPictures(), HttpStatus.OK);
    }

    @PutMapping(value = ApiEndPoints.ADMIN_CONTROLLER.REJECT_PICTURE)
    public ResponseEntity rejectPicture(@PathVariable("adminId") Integer adminId, @RequestParam("pid") Integer pid) {
        Admin admin = adminService.getAdminById(adminId);
        ResponseEntity responseEntity = AdminValidator.validateAdminAuthorityAndPictureExists(admin, adminService.getAdmins(), pid, pictureService.getUnprocessedPictures());
        if (responseEntity != null) {
            return responseEntity;
        }
        pictureService.rejectAndRemovePicture(pid);
        return new ResponseEntity("Succesfully rejected picture and removed metadata", HttpStatus.OK);
    }

    @PutMapping(value = ApiEndPoints.ADMIN_CONTROLLER.ACCEPT_PICTURE)
    public ResponseEntity acceptPicture(@PathVariable("adminId") Integer adminId, @RequestParam(name = "pid") Integer pid) {
        Admin admin = adminService.getAdminById(adminId);
        ResponseEntity responseEntity = AdminValidator.validateAdminAuthorityAndPictureExists(admin, adminService.getAdmins(), pid, pictureService.getUnprocessedPictures());
        if (responseEntity != null) {
            return responseEntity;
        }
        pictureService.acceptPicture(pid);
        return new ResponseEntity("picture status updated Succefully", HttpStatus.OK);

    }

}
