/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.entity.Admin;
import com.nasnav.imagepublishingservice.entity.Picture;
import com.nasnav.imagepublishingservice.model.response.ErrorResponse;
import com.nasnav.imagepublishingservice.model.response.Response;
import com.nasnav.imagepublishingservice.model.response.ImageMetaData;
import com.nasnav.imagepublishingservice.model.response.PictureDataResponse;
import com.nasnav.imagepublishingservice.repository.AdminRepository;
import com.nasnav.imagepublishingservice.repository.PictureRepository;
import com.nasnav.imagepublishingservice.service.AdminService;
import com.nasnav.imagepublishingservice.service.ClientService;
import com.nasnav.imagepublishingservice.service.FileStorageService;
import com.nasnav.imagepublishingservice.service.PictureService;
import com.nasnav.imagepublishingservice.utilities.validators.AdminValidator;
import com.nasnav.imagepublishingservice.utilities.validators.PictureValidator;
import com.nasnav.imagepublishingservice.utilities.validators.Util;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

/**
 *
 * @author abdallah.nazmy
 */
@RestController
@RequestMapping(value = ApiEndPoints.PICTURE_CONTROLLER.CONTROLLER_NAME)
public class PictureController {

    @Autowired
    private PictureService pictureService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private AdminService adminService;
    @Autowired
    private FileStorageService fileStorageService;
    private ObjectMapper objectMapper;

    public PictureController(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @GetMapping(value = ApiEndPoints.PICTURE_CONTROLLER.GET_PICTURES)
    private ResponseEntity getAllPictures() {
        return new ResponseEntity(pictureService.getAllPictures(), HttpStatus.CREATED);
    }
    @GetMapping(value=ApiEndPoints.PICTURE_CONTROLLER.GET_ACCEPTED_PICTURES)
    private ResponseEntity getAcceptedPictures(){
        return new ResponseEntity(pictureService.getAcceptedPictures(),HttpStatus.OK);
    }

    @PostMapping(value = ApiEndPoints.PICTURE_CONTROLLER.UPLOAD_PICTUE)
    private ResponseEntity uploadPicture(@PathVariable("clientId") Long clientId, @RequestParam("description") String description, @RequestParam("category") String category, @RequestParam("image") MultipartFile image) throws Exception {

        ResponseEntity responseEntity = PictureValidator.validateUploadPicture(clientId, clientService.getClients(), image, category);
        if (responseEntity != null) {
            return responseEntity;
        }
        ImageMetaData imageMetaData = fileStorageService.storeFile(image);
        if (PictureValidator.validatePictureFormat(imageMetaData) != null) {
            ErrorResponse errorResponse = PictureValidator.validatePictureFormat(imageMetaData);
            return new ResponseEntity(new Response(errorResponse), HttpStatus.BAD_REQUEST);
        }
        Picture p = Util.preparePicture(clientService.getClientById(clientId), imageMetaData.getFileDownloadUri(), objectMapper.writeValueAsString(imageMetaData), description, category);
        pictureService.uploadPicture(p);
        PictureDataResponse pictureDataResponse = Util.preparePictureDataResponse(p);
        return new ResponseEntity(new Response(pictureDataResponse), HttpStatus.OK);
    }

    

    
}
