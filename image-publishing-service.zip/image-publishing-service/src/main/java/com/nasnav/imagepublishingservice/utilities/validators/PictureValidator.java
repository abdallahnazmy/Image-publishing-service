/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.utilities.validators;

import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.constants.ErrorDefinitions;
import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.model.response.ErrorResponse;
import com.nasnav.imagepublishingservice.model.response.ImageMetaData;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author abdallah.nazmy
 */
public class PictureValidator {

    public static ResponseEntity validateUploadPicture(Long clientId, List<Client> clients, MultipartFile multipartFile, String category) {
        ArrayList<ErrorResponse> caughtErrors = new ArrayList<>();
        caughtErrors.add(validateClientIsLoggedIn(clientId, clients));
        caughtErrors.add(validatePictureCategory(category));
        return ClientValidator.returnErrorResponse(caughtErrors);

    }

    public static ErrorResponse validateClientIsLoggedIn(Long clientId, List<Client> clients) {
        ErrorResponse errorResponse = null;
        boolean exists = false;
        if (!clients.isEmpty()) {
            for (Client c : clients) {
                if (c.getId() == clientId) {
                    exists = true;
                    break;
                }
            }
        }
        if (!exists) {
            errorResponse = new ErrorResponse(ApiEndPoints.PICTURE_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.PICTURE_CONTROLLER.UPLOAD_PICTUE,
                    ErrorDefinitions.ERROR_MESSAGES.CLIENT_NOT_FOUND, ErrorDefinitions.ERROR_CODES.CLIENT_NOT_FOUND);
        }
        return errorResponse;
    }

    public static ErrorResponse validatePictureFormat(ImageMetaData imageMetaData) {
        ErrorResponse errorResponse = null;
        if (imageMetaData == null) {
            errorResponse = new ErrorResponse(ApiEndPoints.PICTURE_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.PICTURE_CONTROLLER.UPLOAD_PICTUE,
                    ErrorDefinitions.ERROR_MESSAGES.PICTURE_NOT_FOUND, ErrorDefinitions.ERROR_CODES.PICTURE_NOT_FOUND);
        }
        return errorResponse;
    }

    public static ErrorResponse validatePictureCategory(String category) {
        ErrorResponse errorResponse = null;
        if (!category.equals(Constants.VALID_PICTURE_CATEGORIES.LIVING_THING) && !category.equals(Constants.VALID_PICTURE_CATEGORIES.MACHING) && !category.equals(Constants.VALID_PICTURE_CATEGORIES.NATURE)) {
            errorResponse = new ErrorResponse(ApiEndPoints.PICTURE_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.PICTURE_CONTROLLER.UPLOAD_PICTUE,
                    ErrorDefinitions.ERROR_MESSAGES.INVALID_PICTURE_CATEGORY, ErrorDefinitions.ERROR_CODES.INVALID_PICTURE_CATEGORY);
        }
        return errorResponse;
    }
}
