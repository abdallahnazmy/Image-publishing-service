/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.constants;

/**
 *
 * @author abdallah.nazmy
 */
public class Constants {

    public static class EMAIL_DOMAINS {

        public static String HOTMAIL = "hotmail.com";
        public static String LIVE = "live.com";
        public static String GMAIL = "gmail.com";
        public static String YAHOO = "yahoo.com";
    }

    public static class PICTURE_STATUS {

        public static final Integer PROCESSING = 0;
        public static final Integer ACCEPTED = 1;
        public static final Integer REJECTED = 2;
    }

    public static class ADMIN_CREDENTIALS {

        public static final String USER_NAME = "admin";
        public static final String PASSWORD = "admin123";
    }

    public static class VALID_EXTENSIONS {

        public static final String JPG = "jpg";
        public static final String PNG = "png";
        public static final String GIF = "gif";

    }

    public static class VALID_PICTURE_CATEGORIES {

        public static final String LIVING_THING = "living thing";
        public static final String MACHING = "machine";
        public static final String NATURE = "nature";
    }

}
