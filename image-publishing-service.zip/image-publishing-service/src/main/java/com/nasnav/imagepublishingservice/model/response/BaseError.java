/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.model.response;

import org.springframework.http.HttpStatus;

/**
 *
 * @author abdallah.nazmy
 */
public abstract class BaseError {

    private final HttpStatus httpStatus;

    public BaseError(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

}
