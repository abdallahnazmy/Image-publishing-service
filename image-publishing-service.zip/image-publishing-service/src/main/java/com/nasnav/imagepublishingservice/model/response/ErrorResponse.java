/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.http.HttpStatus;

/**
 *
 * @author abdallah.nazmy
 */
public class ErrorResponse extends BaseError {

    String controllerPath;
    private String path;
    private String message;
    private String errorCode;

    public ErrorResponse(String controllerPath, String path, String message, String errorCode) {
        super(HttpStatus.INTERNAL_SERVER_ERROR);
        this.controllerPath = controllerPath;
        this.path = path;
        this.message = message;
        this.errorCode = errorCode;
    }

    public String getControllerPath() {
        return controllerPath;
    }

    public void setControllerPath(String controllerPath) {
        this.controllerPath = controllerPath;
    }

    public String getPath() {
        return path;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPath(String path) {
        this.path = path;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

}
