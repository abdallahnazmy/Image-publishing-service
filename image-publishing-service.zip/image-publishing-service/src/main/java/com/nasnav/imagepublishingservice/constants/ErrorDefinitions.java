/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.constants;

/**
 *
 * @author abdallah.nazmy
 */
public class ErrorDefinitions {

    public static class ERROR_CODES {

        public static final String EMAIL_NOT_UNIQUE = "ERROR-1";
        public static final String INVALID_EMAIL_FORMAT = "ERROR-2";
        public static final String UNAUTHARIZED_ACCESS = "ERROR-3";
        public static final String PICTURE_NOT_FOUND = "ERROR-4";
        public static final String CLIENT_NOT_FOUND = "ERROR-5";
        public static final String INVALID_PICTURE_FORMAT = "ERROR-6";
        public static final String INVALID_PICTURE_CATEGORY = "ERROR-7";
    }

    public static class ERROR_MESSAGES {

        public static final String EMAIL_NOT_UNIQUE = "Email must be unique";
        public static final String INVALID_EMAIL_FORMAT = "Email format not valid";
        public static final String UNAUTHARIZED_ACCESS = "Wrong admin credentials";
        public static final String PICTURE_NOT_FOUND = "Picture does not exist";
        public static final String CLIENT_NOT_FOUND = "Client does not exist or may no be signed up";
        public static final String INVALID_PICTURE_FORMAT = "Invalid picture format";
        public static final String INVALID_PICTURE_CATEGORY = "Invalid picture category";

    }
}
