/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.controller;

import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.model.response.Response;
import com.nasnav.imagepublishingservice.repository.ClientRepository;
import com.nasnav.imagepublishingservice.service.ClientService;
import com.nasnav.imagepublishingservice.utilities.validators.ClientValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author abdallah.nazmy
 */
@RestController
@RequestMapping(value = ApiEndPoints.CLIENT_CONTROLLER.CONTROLLER_NAME)
public class ClientController {

    @Autowired
    public ClientService clientService;

    @PostMapping(value = ApiEndPoints.CLIENT_CONTROLLER.CLIENT_SIGNUP)
    public ResponseEntity signUp(@RequestBody Client client) {

        ResponseEntity responseEntity = ClientValidator.validateClientData(client, clientService.getClients());
        if (responseEntity != null) {
            return responseEntity;
        }
        clientService.signUp(client);
        return new ResponseEntity(new Response(client), HttpStatus.CREATED);
    }

    @GetMapping(value = ApiEndPoints.CLIENT_CONTROLLER.GET_CLIENTS)
    public ResponseEntity getClients() {
        return new ResponseEntity(clientService.getClients(), HttpStatus.OK);
    }

}
