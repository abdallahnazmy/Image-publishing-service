/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.model.response;

/**
 *
 * @author abdallah.nazmy
 */
public class ImageMetaData {

    private String fileName;
    private String fileDownloadUri;
    private String extenstion;
    private double size;

    public ImageMetaData(String fileName, String fileDownloadUri, String extension, Long size) {
        this.fileName = fileName;
        this.fileDownloadUri = fileDownloadUri;
        this.extenstion = extension;
        this.size = setToMegaBytes(size);
    }

    public double setToMegaBytes(Long l) {
        double MEGABYTE = 1024 * 1024;
        double b = l.doubleValue() / MEGABYTE;
        return b;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileDownloadUri() {
        return fileDownloadUri;
    }

    public void setFileDownloadUri(String fileDownloadUri) {
        this.fileDownloadUri = fileDownloadUri;
    }

    public String getExtenstion() {
        return extenstion;
    }

    public void setExtenstion(String extenstion) {
        this.extenstion = extenstion;
    }

    public double getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

}
