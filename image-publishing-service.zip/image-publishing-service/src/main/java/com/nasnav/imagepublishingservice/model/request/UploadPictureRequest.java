/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.model.request;

/**
 *
 * @author abdallah.nazmy
 */
public class UploadPictureRequest {
    private String description;
    private String category;
}
