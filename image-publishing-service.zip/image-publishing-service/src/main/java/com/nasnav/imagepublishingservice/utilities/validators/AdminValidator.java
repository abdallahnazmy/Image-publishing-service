/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.utilities.validators;

import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.constants.ErrorDefinitions;
import com.nasnav.imagepublishingservice.entity.Admin;
import com.nasnav.imagepublishingservice.entity.Picture;
import com.nasnav.imagepublishingservice.model.response.ErrorResponse;
import com.nasnav.imagepublishingservice.model.response.PictureDataResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author abdallah.nazmy
 */
public class AdminValidator {

    public static ResponseEntity validateAdminAuthorityAndPictureExists(Admin admin, List<Admin> admins, Integer pid, List<PictureDataResponse> unprocessePicturesList) {
        ArrayList<ErrorResponse> caughtErrors = new ArrayList<>();
        caughtErrors.add(validateAdminExists(admin, admins));
        caughtErrors.add(validatePictureExists(pid, unprocessePicturesList));
        return ClientValidator.returnErrorResponse(caughtErrors);
    }

    public static ErrorResponse validateAdminExists(Admin admin, List<Admin> admins) {
        ErrorResponse errorResponse = null;
        boolean exists = false;
        if (!admins.isEmpty() && admins != null) {
            for (Admin a : admins) {
                if (admin.getUserName().equals(a.getUserName())) {
                    if (admin.getPassword().equals(a.getPassword())) {
                        exists = true;
                        break;
                    }
                }
            }
        }
        if (!exists) {
            errorResponse = new ErrorResponse(ApiEndPoints.ADMIN_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.ADMIN_CONTROLLER.ACCEPT_PICTURE,
                    ErrorDefinitions.ERROR_MESSAGES.UNAUTHARIZED_ACCESS, ErrorDefinitions.ERROR_CODES.UNAUTHARIZED_ACCESS);
        }
        return errorResponse;
    }

    public static ErrorResponse validatePictureExists(Integer pid, List<PictureDataResponse> unprocessedPictures) {
        ErrorResponse errorResponse = null;
        boolean exists = false;
        if (!unprocessedPictures.isEmpty()) {
            for (PictureDataResponse pdr : unprocessedPictures) {
                if (pdr.getPid().equals(pid)) {
                    exists = true;
                    break;
                }
            }
        }
        if (!exists) {
            errorResponse = new ErrorResponse(ApiEndPoints.PICTURE_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.ADMIN_CONTROLLER.ACCEPT_PICTURE,
                    ErrorDefinitions.ERROR_MESSAGES.PICTURE_NOT_FOUND, ErrorDefinitions.ERROR_CODES.PICTURE_NOT_FOUND);
        }
        return errorResponse;
    }

}
