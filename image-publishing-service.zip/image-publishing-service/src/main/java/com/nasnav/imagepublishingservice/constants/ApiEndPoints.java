/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.constants;

/**
 *
 * @author abdallah.nazmy
 */
public class ApiEndPoints {

    public static class CLIENT_CONTROLLER {

        public static final String CONTROLLER_NAME = "client";
        public static final String CLIENT_SIGNUP = "su";
        public static final String GET_CLIENTS = "gc";
    }

    public static class PICTURE_CONTROLLER {

        public static final String CONTROLLER_NAME = "picture";
        public static final String UPLOAD_PICTUE = "/{clientId}/u";
        public static final String GET_PICTURES = "gp";
        public static final String GET_ACCEPTED_PICTURES = "gap";
    }

    public static class ADMIN_CONTROLLER {

        public static final String CONTROLLER_NAME = "admin";
        public static final String CREATE_ADMIN = "ca";
        public static final String ACCEPT_PICTURE = "/{adminId}/ap";
        public static final String REJECT_PICTURE = "/{adminId}/rp";
        public static final String GET_UNPROCESSED_PICTURES = "gup";

    }
}
