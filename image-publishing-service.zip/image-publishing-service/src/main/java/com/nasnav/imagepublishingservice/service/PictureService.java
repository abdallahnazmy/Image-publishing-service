/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.service;

import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.entity.Picture;
import com.nasnav.imagepublishingservice.model.response.PictureDataResponse;
import com.nasnav.imagepublishingservice.repository.PictureRepository;
import com.nasnav.imagepublishingservice.utilities.validators.Util;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.servlet.Registration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author abdallah.nazmy
 */
@Service
public class PictureService {

    @Autowired
    private PictureRepository pictureRepository;

    public List<PictureDataResponse> getAllPictures() {
        List<PictureDataResponse> pictureDataResponsesList = new ArrayList<>();

        if (pictureRepository.findAll() == null) {
            return new ArrayList<>();
        } else {
            for (Picture p : pictureRepository.findAll()) {
                pictureDataResponsesList.add(Util.preparePictureDataResponse(p));
            }
        }
        return pictureDataResponsesList;
    }

    public List<PictureDataResponse> getAcceptedPictures() {
        List<PictureDataResponse> allPicturesList = getAllPictures();
        List<PictureDataResponse> acceptedPicturesList = new ArrayList<>();
        if (allPicturesList != null || !allPicturesList.isEmpty()) {
            for (PictureDataResponse pdr : allPicturesList) {
                if (pdr.getStatus().equals(Constants.PICTURE_STATUS.ACCEPTED)) {
                    acceptedPicturesList.add(pdr);
                }
            }
        }
        return acceptedPicturesList;
    }

    public List<PictureDataResponse> getUnprocessedPictures() {
        List<PictureDataResponse> allPicturesList = getAllPictures();
        List<PictureDataResponse> processingPicturesList = new ArrayList<>();
        if (allPicturesList != null || !allPicturesList.isEmpty()) {
            for (PictureDataResponse pdr : allPicturesList) {
                if (pdr.getStatus().equals(Constants.PICTURE_STATUS.PROCESSING)) {
                    processingPicturesList.add(pdr);
                }
            }
        }
        return processingPicturesList;
    }

    public void acceptPicture(Integer pid) {
        pictureRepository.acceptPicture(Constants.PICTURE_STATUS.ACCEPTED, pid);

    }

    public void rejectAndRemovePicture(Integer pid) {
        pictureRepository.updateAndRejectPicture("", Constants.PICTURE_STATUS.REJECTED, pid);

    }

    public void uploadPicture(Picture picture) {
        pictureRepository.save(picture);
    }

    public Picture getPicture(Integer pid) {
        Picture p = pictureRepository.getById(pid);
        return p;
    }

}
