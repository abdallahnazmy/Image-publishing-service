/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.utilities.validators;

import com.nasnav.imagepublishingservice.constants.ApiEndPoints;
import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.constants.Constants.EMAIL_DOMAINS;
import com.nasnav.imagepublishingservice.constants.ErrorDefinitions;
import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.model.response.ErrorResponse;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author abdallah.nazmy
 */
public class ClientValidator {

    public static ResponseEntity validateClientData(Client client, List<Client> clients) {
        ArrayList<ErrorResponse> caughtErrors = new ArrayList<>();
        caughtErrors.add(isEmailUnique(client, clients));
        caughtErrors.add(isEmailFormatValid(client));
        return returnErrorResponse(caughtErrors);
    }

    public static ErrorResponse isEmailUnique(Client client, List<Client> clients) {
        ErrorResponse errorResponse = null;

        if (!clients.isEmpty() && client != null) {
            for (Client c : clients) {
                if (client.getEmail().equals(c.getEmail())) {
                    errorResponse = new ErrorResponse(ApiEndPoints.CLIENT_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.CLIENT_CONTROLLER.CLIENT_SIGNUP,
                            ErrorDefinitions.ERROR_MESSAGES.EMAIL_NOT_UNIQUE, ErrorDefinitions.ERROR_CODES.EMAIL_NOT_UNIQUE);
                }
                break;
            }
        }
        return errorResponse;
    }

    public static ErrorResponse isEmailFormatValid(Client client) {
        ErrorResponse errorResponse = null;

        String[] emailSplit = client.getEmail().split("@");
        String domain = emailSplit[1];
        if (!domain.equals(EMAIL_DOMAINS.GMAIL) && !domain.equals(EMAIL_DOMAINS.HOTMAIL) && !domain.equals(EMAIL_DOMAINS.LIVE) && !domain.equals(EMAIL_DOMAINS.YAHOO)) {
            errorResponse = new ErrorResponse(ApiEndPoints.CLIENT_CONTROLLER.CONTROLLER_NAME, ApiEndPoints.CLIENT_CONTROLLER.CLIENT_SIGNUP,
                    ErrorDefinitions.ERROR_MESSAGES.INVALID_EMAIL_FORMAT, ErrorDefinitions.ERROR_CODES.INVALID_EMAIL_FORMAT);

        }
        return errorResponse;
    }

    public static ResponseEntity returnErrorResponse(List<ErrorResponse> errors) {
        ResponseEntity responseEntity = null;
        if (!errors.isEmpty()) {
            for (ErrorResponse errorResponse : errors) {
                if (errorResponse != null) {
                    responseEntity = new ResponseEntity(errorResponse, errorResponse.getHttpStatus());
                    break;
                }
            }
        }
        return responseEntity;
    }

}
