/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.utilities.validators;

import com.nasnav.imagepublishingservice.constants.Constants;
import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.entity.Picture;
import com.nasnav.imagepublishingservice.model.response.PictureDataResponse;
import java.util.Date;

/**
 *
 * @author abdallah.nazmy
 */
public class Util {
    
    public static PictureDataResponse preparePictureDataResponse(Picture p) {
        PictureDataResponse pdr = new PictureDataResponse();
        pdr.setPid(p.getpId());
        pdr.setUrl(p.getUrl());
        pdr.setClientId(p.getClient().getId());
        pdr.setCategory(p.getCategory());
        pdr.setDescription(p.getDescription());
        pdr.setStatus(p.getStatus());
        pdr.setUploadDate(p.getUploadeDate());
        return pdr;
    }

    public static Picture preparePicture(Client client, String url, String metaData, String description, String category) {
        Picture picture = new Picture();
        picture.setUrl(url);
        picture.setMetadata(metaData);
        picture.setUploadeDate(new Date(System.currentTimeMillis()));
        picture.setDescription(description);
        picture.setCategory(category);
        picture.setStatus(Constants.PICTURE_STATUS.PROCESSING);
        picture.setClient(client);
        return picture;
    }
}
