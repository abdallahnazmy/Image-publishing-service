/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.nasnav.imagepublishingservice.repository;

import com.nasnav.imagepublishingservice.entity.Picture;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author abdallah.nazmy
 */
@Repository
public interface PictureRepository extends JpaRepository<Picture, Integer> {

    @Transactional
    @Modifying(flushAutomatically = true)
    @Query("UPDATE Picture p set p.status = ?1 where p.pId=?2")
    public void acceptPicture(Integer status, Integer pid);

    @Transactional
    @Modifying(flushAutomatically = true)
    @Query("UPDATE Picture p set p.url = ?1 ,p.status=?2 where p.pId=?3")
    public void updateAndRejectPicture(String url, Integer status, Integer pid);

}
