package com.nasnav.imagepublishingservice;

import com.nasnav.imagepublishingservice.entity.Admin;
import com.nasnav.imagepublishingservice.entity.Client;
import com.nasnav.imagepublishingservice.service.AdminService;
import com.nasnav.imagepublishingservice.service.ClientService;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImagePublishingServiceApplicationTests {

    @Autowired
    AdminService adminService;
    @Autowired
    ClientService clientService;

//    @Test
//    void generateAdmin() {
//        Admin admin = new Admin();
//        adminService.generateAdmin();
//        Assertions.assertEquals("admin", admin.getUserName());
//        Assertions.assertEquals("admin123", admin.getPassword());
//    }
//
//    @Test
//    void testclientSignUp() {
//        Client client = new Client();
//        client.setEmail("A@gmail.com");
//        client.setPassword("password1");
//        Assertions.assertEquals("A@gmail.com", client.getEmail());
//        Assertions.assertEquals("password1", client.getPassword());
//        Assertions.assertNull(client.getPictures());
//    }
    //rest of testing is inculded in the interface document with screenshots of the requests/responses/errorCodes/DBupdates
}
